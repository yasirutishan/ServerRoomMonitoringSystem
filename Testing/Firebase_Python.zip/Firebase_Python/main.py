import random
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import json
import numpy as np
import time

# Fetch the service account key JSON file contents
cred = credentials.Certificate('serviceAccountKey.json')

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://sever-monitoring-system-default-rtdb.asia-southeast1.firebasedatabase.app/'
})

# As an admin, the app has access to read and write all data, regradless of Security Rules
num = 0

while True:
    ref = db.reference("sensor_1_data")
    x = {
            "timeStamp": time.time_ns(),
            "fire": False,
            "humidity": random.randrange(30, 70),
            "temperature": random.randrange(15, 35),
            "voltage": random.randrange(230, 250),
            "vibration": random.randrange(0, 10),
        }

    print(x)
    try:
        print(ref.push(x))
    except:
        print("An exception occurred")
    num += 1
    time.sleep(3)


# ref = db.reference('/users/John')
# print(ref.get())

# x = {
#   "Fname": "John",
#   "Lname": "Smith",
#   "age": 31,
#   "married": True,
#   "divorced": False,
#   "children": ("Ann","Billy"),
#   "pets": None,
#   "cars": [
#     {"model": "BMW 230", "mpg": 27.5},
#     {"model": "Ford Edge", "mpg": 24.1}
#   ]
# }
# print(ref.set(x))
#
